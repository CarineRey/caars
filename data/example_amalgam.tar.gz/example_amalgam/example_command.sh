#! /usr/bash

export OUTDIR="example_outdir"
mkdir -p $OUTDIR

echo "START:"
date
START=$(date +%s)

amalgam.byte  --config  example_amalgam/example_Config_RNA-seq.tsv --species-tree example_amalgam/example_species_tree.nw --alignment-dir example_amalgam/example_family_ali_dir/ --seq2sp-dir example_amalgam/example_family_seq2sp_dir/ --np 8 --memory 100 --outdir $OUTDIR > $OUTDIR/stdout_example.txt 2> $OUTDIR/stderr_example.txt

END=$(date +%s)
DIFF=$(( $END - $START ))
echo "It took $DIFF seconds"
echo "END:"
date

